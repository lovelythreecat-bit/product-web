(() => {
  'use strict';

  const carousel = document.querySelector('.carousel');
  const tabs = Array.from(document.querySelectorAll('[data-slide]'));
  const panes = Array.from(document.querySelectorAll('.hero-pane'));
  const pauseButton = document.getElementById('carousel-pause');
  const announcement = document.getElementById('carousel-announcement');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const duration = 5000;
  let current = 0;
  let elapsed = 0;
  let lastFrame = null;
  let frameId = null;
  let userPaused = reducedMotion.matches;
  let onScreen = true;
  let modalOpen = false;
  const paneAnimations = new Map();
  const motionAnimations = new Set();
  const ease = 'cubic-bezier(.16,1,.3,1)';

  function animateOnce(element, frames, options) {
    if (reducedMotion.matches || !element.animate) return null;
    const animation = element.animate(frames, options);
    motionAnimations.add(animation);
    const forget = () => motionAnimations.delete(animation);
    animation.addEventListener('finish', forget, { once: true });
    animation.addEventListener('cancel', forget, { once: true });
    return animation;
  }

  function settlePanes() {
    paneAnimations.forEach(animation => animation.cancel());
    paneAnimations.clear();
    panes.forEach((pane, i) => {
      pane.hidden = i !== current;
      pane.inert = i !== current;
      pane.setAttribute('aria-hidden', String(i !== current));
    });
  }

  function selectSlide(index, { focus = false, announce = false } = {}) {
    const previous = current;
    const outgoingOpacity = getComputedStyle(panes[previous]).opacity;
    current = (index + tabs.length) % tabs.length;
    settlePanes();
    elapsed = 0;
    lastFrame = null;
    tabs.forEach((tab, i) => {
      const selected = i === current;
      tab.classList.toggle('active', selected);
      tab.setAttribute('aria-selected', String(selected));
      tab.tabIndex = selected ? 0 : -1;
    });
    if (previous !== current && !reducedMotion.matches && panes[current].animate) {
      const outgoing = panes[previous];
      outgoing.hidden = false;
      const exit = outgoing.animate([
        { opacity: outgoingOpacity, transform: 'translateX(0)' },
        { opacity: 0, transform: 'translateX(-8px)' }
      ], { duration: 240, easing: 'ease-out' });
      paneAnimations.set(outgoing, exit);
      exit.onfinish = () => {
        if (paneAnimations.get(outgoing) !== exit) return;
        outgoing.hidden = true;
        paneAnimations.delete(outgoing);
      };
      const incoming = panes[current];
      const enter = incoming.animate([
        { opacity: 0, transform: 'translateX(12px)' },
        { opacity: 1, transform: 'translateX(0)' }
      ], { duration: 460, easing: ease });
      paneAnimations.set(incoming, enter);
      enter.onfinish = () => paneAnimations.delete(incoming);
    }
    if (focus) tabs[current].focus();
    if (announce) announcement.textContent = `已切换：${tabs[current].querySelector('b').textContent}`;
  }

  function canRun() {
    return !userPaused && !document.hidden && onScreen && !modalOpen;
  }

  function tick() {
    frameId = null;
    lastFrame = null;
    if (!canRun()) return;
    selectSlide(current + 1);
    syncTimer();
  }

  function syncTimer() {
    if (frameId !== null) window.clearTimeout(frameId);
    if (lastFrame !== null) elapsed += performance.now() - lastFrame;
    frameId = null;
    lastFrame = null;
    pauseButton.setAttribute('aria-pressed', String(userPaused));
    pauseButton.querySelector('span').textContent = userPaused ? '继续轮播' : '暂停轮播';
    pauseButton.setAttribute('aria-label', userPaused ? '继续自动轮播' : '暂停自动轮播');
    if (canRun()) {
      lastFrame = performance.now();
      frameId = window.setTimeout(tick, Math.max(0, duration - elapsed));
    }
  }

  tabs.forEach((tab, index) => tab.addEventListener('click', () => {
    selectSlide(index, { announce: true });
    syncTimer();
  }));

  carousel.addEventListener('keydown', (event) => {
    if (!['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(event.key)) return;
    // Arrow keys belong to this carousel only, never to the rest of the page.
    if (!event.target.closest('[role="tablist"]') && !event.target.closest('[role="tabpanel"]')) return;
    event.preventDefault();
    let index = current;
    if (event.key === 'ArrowRight') index += 1;
    if (event.key === 'ArrowLeft') index -= 1;
    if (event.key === 'Home') index = 0;
    if (event.key === 'End') index = tabs.length - 1;
    selectSlide(index, { focus: true, announce: true });
    syncTimer();
  });

  pauseButton.addEventListener('click', () => {
    userPaused = !userPaused;
    announcement.textContent = userPaused ? '自动轮播已暂停' : '自动轮播已继续';
    syncTimer();
  });
  document.addEventListener('visibilitychange', syncTimer);
  reducedMotion.addEventListener('change', (event) => {
    if (event.matches) {
      userPaused = true;
      settlePanes();
      motionAnimations.forEach(animation => animation.cancel());
    }
    syncTimer();
  });
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(([entry]) => {
      onScreen = entry.isIntersecting && entry.intersectionRatio >= 0.1;
      syncTimer();
    }, { threshold: [0, 0.1] }).observe(carousel);
  }
  syncTimer();

  settlePanes();
  const navigation = document.querySelector('.navigation');
  const updateNavigation = () => navigation.classList.toggle('is-scrolled', window.scrollY > 12);
  updateNavigation();
  window.addEventListener('scroll', updateNavigation, { passive: true });

  // One focal sequence: message, action, character, then the working canvas.
  [['.hero-intro h1', 0], ['.hero-actions', 100], ['.hero-ling', 150], ['.carousel', 200]].forEach(([selector, delay]) => {
    animateOnce(document.querySelector(selector), [
      { opacity: .15, transform: 'translateY(16px)' },
      { opacity: 1, transform: 'translateY(0)' }
    ], { duration: 700, delay, easing: ease, fill: 'backwards' });
  });

  // Scroll-linked fade in BOTH directions, confined to the viewport edges.
  // Reading area stays fully opaque; no layout movement or persistent RAF loop.
  const fadeElements = Array.from(document.querySelectorAll('.sec-head,.tria,.defcard,.scene,.case,.feat,.shot,.plan,.adbar,.final-content'));
  fadeElements.forEach(el => el.classList.add('scroll-fade'));
  let scrollFrame = null;
  const smoothStep = value => {
    const t = Math.max(0, Math.min(1, value));
    return t * t * (3 - 2 * t);
  };
  function updateScrollFade() {
    scrollFrame = null;
    const topEdge = navigation.getBoundingClientRect().bottom;
    const bottomEdge = window.innerHeight;
    // Batch layout reads before style writes, including large mobile cards.
    const values = fadeElements.map(el => {
      if (reducedMotion.matches) return 1;
      const rect = el.getBoundingClientRect();
      const band = Math.min(120, (bottomEdge - topEdge) * .16, rect.height * .6);
      if (band <= 0) return 1;
      return smoothStep(Math.min((bottomEdge - rect.top) / band, (rect.bottom - topEdge) / band));
    });
    fadeElements.forEach((el, i) => {
      const value = values[i].toFixed(3);
      if (el.style.getPropertyValue('--scroll-opacity') !== value) el.style.setProperty('--scroll-opacity', value);
    });
  }
  function scheduleScrollFade() {
    if (scrollFrame === null) scrollFrame = requestAnimationFrame(updateScrollFade);
  }
  window.addEventListener('scroll', scheduleScrollFade, { passive: true });
  window.addEventListener('resize', scheduleScrollFade, { passive: true });
  window.addEventListener('load', scheduleScrollFade, { once: true });
  window.addEventListener('pageshow', scheduleScrollFade);
  reducedMotion.addEventListener('change', scheduleScrollFade);
  updateScrollFade();

  const menuToggle = document.getElementById('menu-toggle');
  const navLinks = document.getElementById('nav-links');
  function closeMenu({ restore = false } = {}) {
    navLinks.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', '打开导航菜单');
    if (restore) menuToggle.focus();
  }
  menuToggle.addEventListener('click', () => {
    const open = menuToggle.getAttribute('aria-expanded') !== 'true';
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? '关闭导航菜单' : '打开导航菜单');
    navLinks.classList.toggle('open', open);
  });
  navLinks.addEventListener('click', (event) => {
    if (event.target.closest('a')) closeMenu();
  });
  document.addEventListener('click', (event) => {
    if (!event.target.closest('.navigation')) closeMenu();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && menuToggle.getAttribute('aria-expanded') === 'true') closeMenu({ restore: true });
  });
  window.matchMedia('(min-width: 801px)').addEventListener('change', (event) => {
    if (event.matches) closeMenu();
  });

  const dialog = document.getElementById('preview-dialog');
  const dialogBody = document.getElementById('dialog-body');
  const page = document.getElementById('page-content');
  const closeButton = dialog.querySelector('.dialog-close');
  let restoreFocus = null;
  let scrollPosition = 0;
  let afterCloseTarget = null;
  let currentDemo = 'storyboard';
  const artwork = {"0": "<div class=\"art \" data-art=\"work-main\" aria-hidden=\"true\" style=\"--art-ratio:318/184;\"><img src=\"assets/design-lower.png\" alt=\"\" draggable=\"false\" style=\"width:322.01257862%;left:-10.37735849%;top:-318.47826087%;\"></div>", "1": "<div class=\"art \" data-art=\"work-scene\" aria-hidden=\"true\" style=\"--art-ratio:307/185;\"><img src=\"assets/design-lower.png\" alt=\"\" draggable=\"false\" style=\"width:333.55048860%;left:-117.26384365%;top:-316.21621622%;\"></div>", "2": "<div class=\"art \" data-art=\"work-video\" aria-hidden=\"true\" style=\"--art-ratio:317/185;\"><img src=\"assets/design-lower.png\" alt=\"\" draggable=\"false\" style=\"width:323.02839117%;left:-213.24921136%;top:-316.21621622%;\"></div>", "10": "<div class=\"art \" data-art=\"scene-beginner\" aria-hidden=\"true\" style=\"--art-ratio:463/111;\"><img src=\"assets/design-upper.png\" alt=\"\" draggable=\"false\" style=\"width:221.16630670%;left:-111.23110151%;top:-1086.48648649%;\"></div>", "11": "<div class=\"art \" data-art=\"feature-video\" aria-hidden=\"true\" style=\"--art-ratio:231/126;\"><img src=\"assets/design-lower.png\" alt=\"\" draggable=\"false\" style=\"width:443.29004329%;left:-120.34632035%;top:-61.11111111%;\"></div>"};
  const picture = (i, extra = "", label = "") => `<div class="modal-picture ${extra}" role="img" aria-label="${label}">${artwork[i] || artwork[0]}</div>`;
  const demos = {
    storyboard: [
      { image: 2, label: '分镜 1 / 3 · 通勤场景', title: '带上轻便，一起出发', copy: '城市通勤的日常，用一只保温杯把温度带在身边。' },
      { image: 0, label: '分镜 2 / 3 · 商品特写', title: '让商品细节被看见', copy: '银色杯身与简约外观，在画面中清楚呈现。' },
      { image: 1, label: '分镜 3 / 3 · 生活场景', title: '日常好物，自然融入生活', copy: '从上班通勤到桌面一角，完成一组连贯的商品表达。' }
    ],
    demo: [
      { image: 0, label: '功能演示 1 / 3 · 准备商品', title: '从一张商品图开始', copy: '告诉飞马：「我要卖一款保温杯，主打上班通勤」，把想法变成创作方向。' },
      { image: 10, label: '功能演示 2 / 3 · 对话创作', title: '玲玲陪你选风格、出图与微调', copy: '小白用对话表达想法；老手使用图层、参数、批量与模板，掌握更多创作细节。' },
      { image: 11, label: '功能演示 3 / 3 · 查看成果', title: '一套创意，多种营销表达', copy: '查看主图、场景海报与短视频分镜，了解同一款商品的多种呈现方式。' }
    ]
  };

  function showDialog(html) {
    if (dialog.open) {
      dialogBody.innerHTML = html;
      dialog.scrollTop = 0;
      closeButton.focus({ preventScroll: true });
      return;
    }
    restoreFocus = document.activeElement;
    scrollPosition = window.scrollY;
    dialogBody.innerHTML = html;
    modalOpen = true;
    syncTimer();
    dialog.showModal();
    page.inert = true;
    document.body.style.overflow = 'hidden';
    dialog.scrollTop = 0;
    closeButton.focus({ preventScroll: true });
  }

  function closeDialog() {
    if (!dialog.open) return;
    dialog.close();
  }

  dialog.addEventListener('close', () => {
    page.inert = false;
    document.body.style.overflow = '';
    modalOpen = false;
    syncTimer();
    window.scrollTo({ top: scrollPosition, behavior: 'instant' });
    if (restoreFocus && restoreFocus.isConnected) restoreFocus.focus({ preventScroll: true });
    if (afterCloseTarget) {
      afterCloseTarget.scrollIntoView({ behavior: reducedMotion.matches ? 'instant' : 'smooth', block: 'start' });
      afterCloseTarget = null;
    }
  });
  closeButton.addEventListener('click', closeDialog);
  dialog.addEventListener('cancel', (event) => { event.preventDefault(); closeDialog(); });
  dialog.addEventListener('click', (event) => {
    const rect = dialog.getBoundingClientRect();
    if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) closeDialog();
  });
  dialog.addEventListener('keydown', (event) => {
    if (event.key !== 'Tab') return;
    const focusables = Array.from(dialog.querySelectorAll('button,a[href],[tabindex="0"]')).filter(el => !el.disabled && !el.hidden);
    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });

  function showDemo(type) {
    currentDemo = type;
    const isVideo = type === 'storyboard';
    showDialog(`<h2 id="dialog-title">${isVideo ? '保温杯 · 通勤种草分镜' : '看飞马如何创作'}</h2><p id="dialog-description">${isVideo ? '这是本地静态分镜演示。点击下方步骤查看画面与说明；这里没有视频文件或真实视频播放。' : '这是独立预览中的本地功能演示。点击步骤了解商品从想法到成果的过程，不会调用 AI 或提交生成任务。'}</p><div class="demo-stage"><div class="demo-image" id="demo-image"></div><div class="demo-caption" id="demo-caption" aria-live="polite"></div></div><div class="demo-steps" role="group" aria-label="${isVideo ? '查看分镜' : '查看演示步骤'}">${demos[type].map((_, i) => `<button class="demo-step" data-demo-step="${i}" aria-pressed="${i === 0}">${isVideo ? ['通勤场景', '商品特写', '生活场景'][i] : ['准备商品', '对话创作', '查看成果'][i]}</button>`).join('')}</div><p class="dialog-note">画面为创作示例，未连接真实生成、店铺发布或经营数据。</p>`);
    setDemoStep(0);
  }

  function setDemoStep(index) {
    const step = demos[currentDemo][index];
    if (!step) return;
    document.getElementById('demo-image').innerHTML = picture(step.image, '', step.title) + `<span class="demo-label">${step.label}</span>`;
    document.getElementById('demo-caption').innerHTML = `<h3>${step.title}</h3><p>${step.copy}</p>`;
    dialog.querySelectorAll('[data-demo-step]').forEach((button, i) => button.setAttribute('aria-pressed', String(i === index)));
  }

  function showInfo(action, trigger) {
    const copy = {
      trial: ['先看见你的第一组好作品', '这是独立首页预览，暂未接入注册或账户系统。你可以先浏览作品，或查看本地创作演示；此操作不会创建账户。'],
      standard: ['标准版 · ¥99 / 月', '当前展示的是原稿套餐示意。独立预览未接入订阅或支付，此操作不会开通套餐，也不会产生付款。可以先浏览作品，了解创作表现。'],
      consult: ['一起找到合适的创作方案', '独立预览暂未接入顾问联系通道，此操作没有发送消息或提交联系资料。你可以先查看作品与本地演示，了解旗舰版的创作方向。'],
      lingling: ['玲玲，陪你从想法到出片', '这是玲玲数字人的独立展示预览，尚未接入实时 AI 客服。现在可以通过本地功能演示，看看她如何陪你选风格、出图、微调与发布。'],
      resource: [trigger.textContent.trim(), '此独立预览尚未接入该服务或内容页面。你可以继续浏览创作场景、作品展示和套餐说明；此操作不会跳转至业务系统。']
    };
    const [title, description] = copy[action];
    showDialog(`<h2 id="dialog-title">${title}</h2><p id="dialog-description">${description}</p><div class="dialog-actions"><button class="button button-primary" data-modal-action="works">浏览作品</button><button class="dialog-link" data-modal-action="demo">查看本地演示</button></div>`);
  }

  document.addEventListener('click', (event) => {
    const stepButton = event.target.closest('[data-demo-step]');
    if (stepButton) { setDemoStep(Number(stepButton.dataset.demoStep)); return; }
    const modalAction = event.target.closest('[data-modal-action]');
    if (modalAction) {
      if (modalAction.dataset.modalAction === 'works') {
        afterCloseTarget = document.getElementById('works');
        closeDialog();
      } else {
        // Reuse the open dialog so its original return focus and isolation remain intact.
        showDemo('demo');
      }
      return;
    }
    const trigger = event.target.closest('[data-action]');
    if (!trigger) return;
    event.preventDefault();
    const action = trigger.dataset.action;
    if (action === 'demo' || action === 'storyboard') { showDemo(action); return; }
    if (action === 'image-main' || action === 'image-scene') {
      const mainImage = action === 'image-main';
      const title = mainImage ? '保温杯 · 电商主图' : '保温杯 · 种草海报';
      showDialog(`<h2 id="dialog-title">${title}</h2><p id="dialog-description">${mainImage ? '文生图 · 白底主图' : '文生图 · 场景海报'}，创作示例。</p>${picture(mainImage ? 0 : 1, 'dialog-art', title)}`);
      return;
    }
    showInfo(action, trigger);
  });
})();
